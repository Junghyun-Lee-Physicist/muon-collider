#ifndef TEMP_HH
#define TEMP_HH

class Temp {
public:
    void PrintMessage();
};

#endif

