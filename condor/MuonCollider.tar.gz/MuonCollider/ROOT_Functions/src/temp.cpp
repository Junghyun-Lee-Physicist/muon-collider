#include "temp.hh"
#include <iostream>

void Temp::PrintMessage() {
    std::cout << "This is a message from Temp class." << std::endl;
}

